const PETALS = new Array(14).fill(0).map((_, i) => ({
  left: `${(i * 7.3) % 100}%`,
  duration: 10 + (i % 5) * 3,
  delay: -(i * 1.7),
  scale: 0.6 + ((i * 37) % 10) / 10,
}))

export default function PetalField() {
  return (
    <div className="petal-field" aria-hidden="true">
      {PETALS.map((p, i) => (
        <span
          key={i}
          className="petal"
          style={{
            left: p.left,
            animationDuration: `${p.duration}s`,
            animationDelay: `${p.delay}s`,
            transform: `scale(${p.scale})`,
          }}
        />
      ))}
    </div>
  )
}
