export default function Footer() {
  return (
    <footer className="footer">
      <p className="notice">
        Anime data, synopses and artwork are fetched live from Jikan, a free public API built on
        MyAnimeList, and belong to their respective studios, publishers and rights holders.
        SakuraGirl does not host, store or distribute any video, streaming or download files.
      </p>
      <div className="container footer-row">
        <span>© {new Date().getFullYear()} SakuraGirl · Built by Supun Fernando</span>
        <div className="footer-links">
          <a href="https://supunofc.site" target="_blank" rel="noreferrer">supunofc.site</a>
          <a href="https://www.youtube.com/@darkshadow_zap" target="_blank" rel="noreferrer">YouTube</a>
          <a href="https://whatsapp.com/channel/0029Vb76Ri8JkK7GrUmDbp1x" target="_blank" rel="noreferrer">WhatsApp</a>
        </div>
      </div>
    </footer>
  )
}
