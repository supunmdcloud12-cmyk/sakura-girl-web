export default function SkeletonGrid({ count = 12 }) {
  return (
    <div className="grid">
      {new Array(count).fill(0).map((_, i) => (
        <div key={i} className="skeleton skeleton-card" />
      ))}
    </div>
  )
}
