import { Link } from 'react-router-dom'

export default function AnimeCard({ anime }) {
  const image = anime.images?.webp?.image_url || anime.images?.jpg?.image_url
  const score = anime.score
  const year = anime.year || anime.aired?.prop?.from?.year
  const type = anime.type

  return (
    <Link to={`/anime/${anime.mal_id}`} className="card">
      <div className="card-media">
        {image && <img src={image} alt={anime.title} loading="lazy" />}
        {score && (
          <div className="card-score">
            <div className="score-ring" style={{ '--pct': Math.min(100, Math.round(score * 10)) }}>
              <div className="score-ring-inner">{score}</div>
            </div>
          </div>
        )}
      </div>
      <div className="card-body">
        <h3 className="card-title">{anime.title}</h3>
        <div className="card-meta">
          {type && <span className="pill">{type}</span>}
          {year && <span>{year}</span>}
        </div>
      </div>
    </Link>
  )
}
