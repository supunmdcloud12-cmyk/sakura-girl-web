import { useEffect, useRef, useState } from 'react'
import { useSearchParams } from 'react-router-dom'
import { searchAnime, getTopAnime, getSeasonNow } from '../api/jikan'
import { searchAnimeAniList, getTrendingAniList } from '../api/anilist'
import AnimeCard from '../components/AnimeCard'
import SkeletonGrid from '../components/SkeletonGrid'
import PetalField from '../components/PetalField'

export default function Home() {
  const [params, setParams] = useSearchParams()
  const initialQuery = params.get('q') || ''
  const [query, setQuery] = useState(initialQuery)
  const [results, setResults] = useState(null)
  const [trending, setTrending] = useState([])
  const [season, setSeason] = useState([])
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState(null)
  const debounceRef = useRef(null)

  useEffect(() => {
    getTopAnime()
      .then((d) => setTrending(d.data || []))
      .catch(() => {
        // Jikan unavailable — fall back to AniList so the row still fills in.
        getTrendingAniList().then(setTrending).catch(() => {})
      })
    getSeasonNow().then((d) => setSeason(d.data || [])).catch(() => {})
  }, [])

  useEffect(() => {
    if (!initialQuery) {
      setResults(null)
      return
    }
    runSearch(initialQuery)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [initialQuery])

  async function runSearch(q) {
    if (!q.trim()) {
      setResults(null)
      setParams({})
      return
    }
    setLoading(true)
    setError(null)
    try {
      const data = await searchAnime(q)
      setResults(data.data || [])
    } catch (jikanErr) {
      // Jikan down or rate-limited — fall back to AniList before giving up.
      try {
        const fallback = await searchAnimeAniList(q)
        setResults(fallback)
      } catch (aniListErr) {
        setError(jikanErr.message || 'Something went wrong.')
        setResults([])
      }
    } finally {
      setLoading(false)
    }
  }

  function handleSubmit(e) {
    e.preventDefault()
    setParams(query ? { q: query } : {})
    runSearch(query)
  }

  function handleChange(value) {
    setQuery(value)
    clearTimeout(debounceRef.current)
    debounceRef.current = setTimeout(() => {
      setParams(value ? { q: value } : {})
      runSearch(value)
    }, 500)
  }

  const showingSearch = results !== null

  return (
    <>
      <section className="hero">
        <span className="hero-glyph">桜</span>
        <PetalField />
        <div className="container hero-inner">
          <span className="eyebrow-tag">Anime search, powered by MyAnimeList data</span>
          <h1>Find any anime, then fall into its world.</h1>
          <p className="lede">
            Search thousands of series and films, open a title for its full synopsis, ratings,
            genres and cast, and pick up where a recommendation left off.
          </p>
          <div className="search-panel">
            <form className="search-form" onSubmit={handleSubmit}>
              <input
                type="text"
                value={query}
                onChange={(e) => handleChange(e.target.value)}
                placeholder="Search a title — try “Frieren” or “Bocchi the Rock”"
                aria-label="Search anime"
              />
              <button type="submit" disabled={loading}>
                {loading ? 'Searching…' : 'Search'}
              </button>
            </form>
            <p className="search-hint">Results start appearing as you type.</p>
          </div>
        </div>
      </section>

      <div className="container">
        {showingSearch ? (
          <section className="section">
            <div className="section-head">
              <h2>Results for “{initialQuery}”</h2>
              {!loading && <span className="count">{results.length} found</span>}
            </div>
            {loading && <SkeletonGrid count={12} />}
            {!loading && error && (
              <div className="state-block">
                <h3>Couldn't load results</h3>
                <p>{error}</p>
              </div>
            )}
            {!loading && !error && results.length === 0 && (
              <div className="state-block">
                <h3>No matches</h3>
                <p>Try a different spelling, or search an English or Japanese title.</p>
              </div>
            )}
            {!loading && !error && results.length > 0 && (
              <div className="grid">
                {results.map((a) => (
                  <AnimeCard key={a.mal_id} anime={a} />
                ))}
              </div>
            )}
          </section>
        ) : (
          <>
            <section className="section">
              <div className="section-head">
                <h2>Airing this season</h2>
              </div>
              {season.length === 0 ? (
                <SkeletonGrid count={6} />
              ) : (
                <div className="grid">
                  {season.slice(0, 12).map((a) => (
                    <AnimeCard key={a.mal_id} anime={a} />
                  ))}
                </div>
              )}
            </section>

            <section className="section">
              <div className="section-head">
                <h2>Trending now</h2>
              </div>
              {trending.length === 0 ? (
                <SkeletonGrid count={12} />
              ) : (
                <div className="grid">
                  {trending.map((a) => (
                    <AnimeCard key={a.mal_id} anime={a} />
                  ))}
                </div>
              )}
            </section>
          </>
        )}
      </div>
    </>
  )
}
