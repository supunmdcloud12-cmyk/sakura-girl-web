const SOCIALS = [
  { label: 'Main website — supunofc.site', href: 'https://supunofc.site' },
  { label: 'YouTube — @darkshadow_zap', href: 'https://www.youtube.com/@darkshadow_zap' },
  { label: 'WhatsApp Channel', href: 'https://whatsapp.com/channel/0029Vb76Ri8JkK7GrUmDbp1x' },
  { label: 'WhatsApp Channel', href: 'https://whatsapp.com/channel/0029Vb55cv41nozBTTIw1y07' },
]

const FOCUS = [
  {
    k: 'Anime',
    body: 'A home base for tracking and discovering series — search, synopses, ratings and cast, sourced from open anime data.',
  },
  {
    k: '3D',
    body: 'Explorations in 3D modelling and rendering, built alongside the anime and design work on this site.',
  },
  {
    k: 'UI / UX Design',
    body: 'Interface and product design work, with an eye for layouts and type systems that feel considered rather than templated.',
  },
]

export default function About() {
  return (
    <>
      <section className="about-hero">
        <div className="container">
          <span className="eyebrow-tag">About SakuraGirl</span>
          <h1 className="details-title-en" style={{ maxWidth: 620 }}>
            One site, three obsessions: anime, 3D, and interface design.
          </h1>
          <p className="lede" style={{ marginTop: 18, maxWidth: 560 }}>
            SakuraGirl started as a way to search and keep track of anime without wading through
            cluttered pages. It's grown into a small showcase for everything else in the works too.
          </p>
        </div>
      </section>

      <div className="container about-grid">
        <div className="focus-list">
          {FOCUS.map((f) => (
            <div className="focus-item" key={f.k}>
              <div className="k">{f.k}</div>
              <p>{f.body}</p>
            </div>
          ))}
        </div>

        <div className="owner-card">
          <div className="role">Owner &amp; builder</div>
          <div className="name">Mr. Supun Fernando</div>
          <p className="bio">
            Builds and maintains SakuraGirl, alongside ongoing work in 3D art and UI/UX design.
            Find more of that work and get in touch through the links below.
          </p>
          <div className="social-list">
            {SOCIALS.map((s) => (
              <a href={s.href} target="_blank" rel="noreferrer" key={s.href}>
                {s.label}
                <span aria-hidden="true">↗</span>
              </a>
            ))}
          </div>
        </div>
      </div>
    </>
  )
}
