import { useEffect, useState } from 'react'
import { Link, useParams } from 'react-router-dom'
import { getAnimeDetails, getAnimeCharacters } from '../api/jikan'
import { getAnimeDetailsAniList } from '../api/anilist'

export default function Details() {
  const { id } = useParams()
  const [anime, setAnime] = useState(null)
  const [characters, setCharacters] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)

  useEffect(() => {
    setLoading(true)
    setError(null)
    setAnime(null)
    Promise.all([getAnimeDetails(id), getAnimeCharacters(id).catch(() => [])])
      .then(([details, chars]) => {
        setAnime(details)
        setCharacters(chars.slice(0, 8))
      })
      .catch(() => {
        // Jikan unavailable for this id — fall back to AniList.
        // (Only works when the id also resolves on AniList; otherwise show the error.)
        getAnimeDetailsAniList(id)
          .then(({ details, characters }) => {
            setAnime(details)
            setCharacters(characters.slice(0, 8))
          })
          .catch((err) => setError(err.message || 'Could not load this title.'))
      })
      .finally(() => setLoading(false))
    window.scrollTo(0, 0)
  }, [id])

  if (loading) {
    return (
      <div className="container">
        <div className="state-block">
          <h3>Loading…</h3>
        </div>
      </div>
    )
  }

  if (error || !anime) {
    return (
      <div className="container">
        <Link to="/" className="back-link">← Back to search</Link>
        <div className="state-block">
          <h3>Couldn't load this title</h3>
          <p>{error}</p>
        </div>
      </div>
    )
  }

  const image = anime.images?.webp?.large_image_url || anime.images?.jpg?.large_image_url

  return (
    <>
      <section className="details-hero">
        <div className="details-hero-bg">{image && <img src={image} alt="" aria-hidden="true" />}</div>
        <div className="container details-hero-inner">
          <div className="details-poster">
            {image && <img src={image} alt={anime.title} />}
          </div>
          <div>
            <Link to="/" className="back-link">← Back to search</Link>
            <h1 className="details-title-en">{anime.title_english || anime.title}</h1>
            {anime.title_japanese && <p className="details-title-jp">{anime.title_japanese}</p>}

            <div className="details-tags">
              {anime.genres?.map((g) => (
                <span className="tag" key={g.mal_id}>{g.name}</span>
              ))}
              {anime.type && <span className="tag">{anime.type}</span>}
              {anime.status && <span className="tag">{anime.status}</span>}
            </div>

            <div className="details-stats">
              {anime.score && (
                <div className="stat-card">
                  <div className="score-ring score-ring-lg" style={{ '--pct': Math.min(100, Math.round(anime.score * 10)) }}>
                    <div className="score-ring-inner">{anime.score}</div>
                  </div>
                  <div className="label">Score · {anime.scored_by?.toLocaleString() || '—'} votes</div>
                </div>
              )}
              {anime.rank && (
                <div className="stat-card">
                  <div className="num">#{anime.rank}</div>
                  <div className="label">Ranked</div>
                </div>
              )}
              {anime.episodes && (
                <div className="stat-card">
                  <div className="num">{anime.episodes}</div>
                  <div className="label">Episodes</div>
                </div>
              )}
              {anime.year && (
                <div className="stat-card">
                  <div className="num">{anime.year}</div>
                  <div className="label">Year</div>
                </div>
              )}
            </div>
          </div>
        </div>
      </section>

      <div className="container details-body">
        <div>
          <h3>Synopsis</h3>
          <p className="synopsis">{anime.synopsis || 'No synopsis available for this title yet.'}</p>

          {characters.length > 0 && (
            <div className="char-strip">
              <h3>Main characters</h3>
              <div className="char-grid">
                {characters.map((c) => (
                  <div className="char-card" key={c.character.mal_id}>
                    <img
                      src={c.character.images?.webp?.image_url || c.character.images?.jpg?.image_url}
                      alt={c.character.name}
                      loading="lazy"
                    />
                    <p className="name">{c.character.name}</p>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        <aside style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>
          <div className="info-card">
            <InfoRow k="Studio" v={anime.studios?.map((s) => s.name).join(', ')} />
            <InfoRow k="Source" v={anime.source} />
            <InfoRow k="Duration" v={anime.duration} />
            <InfoRow k="Rating" v={anime.rating} />
            <InfoRow k="Aired" v={anime.aired?.string} />
            <InfoRow k="Season" v={anime.season ? `${anime.season} ${anime.year || ''}`.trim() : null} />
            <InfoRow k="Popularity" v={anime.popularity ? `#${anime.popularity}` : null} />
          </div>

          <WatchOfficially title={anime.title_english || anime.title} malUrl={anime.url} />
        </aside>
      </div>
    </>
  )
}

function WatchOfficially({ title, malUrl }) {
  const q = encodeURIComponent(title || '')
  const links = [
    { label: 'Search on Crunchyroll', href: `https://www.crunchyroll.com/search?q=${q}` },
    { label: 'Search on Netflix', href: `https://www.netflix.com/search?q=${q}` },
    ...(malUrl ? [{ label: 'View on MyAnimeList', href: malUrl }] : []),
  ]

  return (
    <div className="info-card">
      <h3 style={{ fontSize: 15, marginBottom: 6 }}>Watch officially</h3>
      <div className="social-list" style={{ marginTop: 10 }}>
        {links.map((l) => (
          <a href={l.href} target="_blank" rel="noreferrer" key={l.href}>
            {l.label}
            <span aria-hidden="true">↗</span>
          </a>
        ))}
      </div>
    </div>
  )
}

function InfoRow({ k, v }) {
  if (!v) return null
  return (
    <div className="info-row">
      <span className="k">{k}</span>
      <span className="v">{v}</span>
    </div>
  )
}
