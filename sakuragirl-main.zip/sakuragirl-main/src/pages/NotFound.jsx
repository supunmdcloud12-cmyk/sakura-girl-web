import { Link } from 'react-router-dom'

export default function NotFound() {
  return (
    <div className="container">
      <div className="state-block">
        <h3>This page doesn't exist</h3>
        <p>
          <Link to="/">Back to search</Link>
        </p>
      </div>
    </div>
  )
}
