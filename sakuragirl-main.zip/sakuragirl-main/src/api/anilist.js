// Fallback data source: AniList's free, public GraphQL API.
// Docs: https://docs.anilist.co/
// Used automatically when Jikan is unavailable or rate-limited, so search
// and browsing keep working. Results are normalized to the same shape
// AnimeCard / Details already expect (mal_id, title, images, score, ...).

const ANILIST_URL = 'https://graphql.anilist.co'

async function query(gql, variables) {
  const res = await fetch(ANILIST_URL, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
    body: JSON.stringify({ query: gql, variables }),
  })
  if (!res.ok) throw new Error(`AniList request failed (${res.status})`)
  const json = await res.json()
  if (json.errors) throw new Error(json.errors[0]?.message || 'AniList error')
  return json.data
}

function normalize(media) {
  return {
    mal_id: media.idMal || media.id,
    anilist_id: media.id,
    title: media.title?.english || media.title?.romaji || media.title?.native,
    title_english: media.title?.english,
    title_japanese: media.title?.native,
    type: media.format,
    status: media.status,
    year: media.seasonYear || media.startDate?.year,
    episodes: media.episodes,
    score: media.averageScore ? Math.round(media.averageScore) / 10 : null,
    scored_by: null,
    rank: null,
    popularity: media.popularity,
    duration: media.duration ? `${media.duration} min per ep` : null,
    source: media.source,
    rating: null,
    genres: (media.genres || []).map((g, i) => ({ mal_id: `${g}-${i}`, name: g })),
    studios: (media.studios?.nodes || []).map((s) => ({ name: s.name })),
    synopsis: media.description ? stripHtml(media.description) : null,
    url: media.siteUrl,
    aired: { string: media.startDate?.year ? `${media.startDate.year}` : null },
    images: {
      webp: { image_url: media.coverImage?.large, large_image_url: media.coverImage?.extraLarge },
      jpg: { image_url: media.coverImage?.large, large_image_url: media.coverImage?.extraLarge },
    },
    _source: 'anilist',
  }
}

function stripHtml(str) {
  return str.replace(/<[^>]*>/g, '').replace(/\n{2,}/g, '\n\n').trim()
}

const SEARCH_QUERY = `
  query ($search: String, $page: Int) {
    Page(page: $page, perPage: 18) {
      media(search: $search, type: ANIME, sort: POPULARITY_DESC) {
        id idMal format status episodes averageScore popularity duration source
        seasonYear startDate { year }
        title { romaji english native }
        genres
        studios(isMain: true) { nodes { name } }
        description(asHtml: false)
        siteUrl
        coverImage { large extraLarge }
      }
    }
  }
`

const TRENDING_QUERY = `
  query ($page: Int) {
    Page(page: $page, perPage: 12) {
      media(sort: TRENDING_DESC, type: ANIME) {
        id idMal format status episodes averageScore popularity duration source
        seasonYear startDate { year }
        title { romaji english native }
        genres
        studios(isMain: true) { nodes { name } }
        description(asHtml: false)
        siteUrl
        coverImage { large extraLarge }
      }
    }
  }
`

const DETAILS_QUERY = `
  query ($id: Int) {
    Media(id: $id, type: ANIME) {
      id idMal format status episodes averageScore popularity duration source
      seasonYear startDate { year } endDate { year }
      title { romaji english native }
      genres
      studios(isMain: true) { nodes { name } }
      description(asHtml: false)
      siteUrl
      coverImage { large extraLarge }
      characters(sort: ROLE, perPage: 8) {
        edges {
          node { id name { full } image { large medium } }
        }
      }
    }
  }
`

export async function searchAnimeAniList(q, page = 1) {
  const data = await query(SEARCH_QUERY, { search: q, page })
  return (data.Page.media || []).map(normalize)
}

export async function getTrendingAniList(page = 1) {
  const data = await query(TRENDING_QUERY, { page })
  return (data.Page.media || []).map(normalize)
}

export async function getAnimeDetailsAniList(id) {
  const data = await query(DETAILS_QUERY, { id: Number(id) })
  const media = data.Media
  const normalized = normalize(media)
  const characters = (media.characters?.edges || []).map((e) => ({
    character: {
      mal_id: e.node.id,
      name: e.node.name?.full,
      images: {
        webp: { image_url: e.node.image?.large || e.node.image?.medium },
        jpg: { image_url: e.node.image?.large || e.node.image?.medium },
      },
    },
  }))
  return { details: normalized, characters }
}
