// Thin wrapper around the free, public Jikan API (unofficial MyAnimeList REST API).
// Docs: https://docs.api.jikan.moe/
// No API key required. Please be considerate of Jikan's public rate limits
// (roughly 3 requests/second, 60/minute) if you extend this further.

const BASE_URL = 'https://api.jikan.moe/v4'

async function request(path) {
  const res = await fetch(`${BASE_URL}${path}`)
  if (!res.ok) {
    if (res.status === 429) {
      throw new Error('Too many requests right now — please wait a moment and try again.')
    }
    throw new Error(`Request failed (${res.status})`)
  }
  return res.json()
}

export async function searchAnime(query, page = 1) {
  const q = encodeURIComponent(query.trim())
  const data = await request(`/anime?q=${q}&sfw=true&page=${page}&limit=18&order_by=popularity&sort=asc`)
  return data
}

export async function getTopAnime(page = 1) {
  const data = await request(`/top/anime?page=${page}&limit=12&filter=bypopularity`)
  return data
}

export async function getSeasonNow(page = 1) {
  const data = await request(`/seasons/now?page=${page}&limit=12&sfw=true`)
  return data
}

export async function getAnimeDetails(id) {
  const data = await request(`/anime/${id}/full`)
  return data.data
}

export async function getAnimeCharacters(id) {
  const data = await request(`/anime/${id}/characters`)
  return data.data
}
